/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day2_14march;

import java.util.*;

/**
 *
 * @author macstudent
 */
public class Day2_14MARCH {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        //create a object of bank class
        Bank B1 = new Bank();
        System.out.println("Bank ID is: " + B1.bankId);
        System.out.println("Bank Name is: " + B1.bankName);
        System.out.println("-------------------");
        Bank B2 = new Bank();

        B1.bankId = 1232;
        B1.bankName = "TD";

        System.out.println("Bank ID is: " + B1.bankId);
        System.out.println("Bank Name is: " + B1.bankName);

        System.out.println("-------------------");
        System.out.println("Bank ID is: " + B2.bankId);
        System.out.println("Bank Name is: " + B2.bankName);

        System.out.println("-------------------");

        B2.getBankName();
        B2.setBankName("ICICI");
        B2.getBankName();
        System.out.println("-------------------");
        
        Scanner myID = new Scanner(System.in);
        int ide;
        System.out.println("Enter Bank ID : ");
        //providing memory to the text given my user 
        //nextline for string bcz string is ended by any new line
        ide = myID.nextInt();
        B2.setBankID(ide);
        B2.getBankID();

        
        Scanner myInput = new Scanner(System.in);
        String name;
        System.out.println("Enter Bank Name : ");
        //providing memory to the text given my user 
        //nextline for string bcz string is ended by any new line
        name = myInput.nextLine();
        B2.setBankName(name);
        B2.getBankName();

        System.out.println("-------------------");
        Arithmetic A1 = new Arithmetic();
        System.out.println("Addition of these numbers is: " + A1.addition(2, 4));
        System.out.println("Addition of these numbers is: " + A1.addition(78.8f, 46.7f));
        System.out.println("Addition of these numbers is: " + A1.addition(2, 4, 5, 6));
        System.out.println("Multiplication of these numbers is: " + A1.multiplication(2,4));
        
        //can acces using class because declared as static
        System.out.println("Multiplication of these numbers is: " + Arithmetic.multiplication(10,20));
         //cannot acces using class because not declared as static
        //System.out.println("Addition of these numbers is: " + Arithmetic.addition(10,20));
        
       Arithmetic.n1 = 20;
      
        System.out.println("N1 is : " + Arithmetic.n1 + " & " + "N2 is : " + Arithmetic.n2);
    }

}
