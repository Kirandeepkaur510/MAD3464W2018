/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day2_inheritence;

/**
 *
 * @author macstudent
 */
public class Day2_Inheritence {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Using Object of Person");
        
        Person P1 = new Person();
        //P1.readData();
        System.out.println("Default Constructor will be executed");
        P1.display();
        
        System.out.println("Parameterized Constructor will be executed");
        Person P2 = new Person("Ashnoor","Brar",19);
        P2.display();
        
        System.out.println("Copy Constructor will be executed");
        Person P3 = new Person(P2);
        P3.display();
        System.out.println(" ---------  ");
        System.out.println("Using Object of Employee");
        //object with parameter
        System.out.println("Parameterized Constructor of Employee");
        Employee E1 = new Employee("rashmeen","brar", 18, 45.90);
        E1.display();
        //object with no parameter
        System.out.println("Default Constructor of Employee");
        Employee E2 = new Employee();
        E2.display();
        //accessing person class
        E2.firstName = "Kirandeep";
        E2.lastName = "Kaur";
        E2.age = 22;
        E2.salary = 1200;
        E2.display();
        E2.display();
        
        //method overriding
        //read and display override the functions of person
        Employee E3 = new Employee();
        E3.read();
        E3.display();
    }
    
}
