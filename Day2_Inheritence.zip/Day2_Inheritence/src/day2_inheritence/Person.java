/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day2_inheritence;
import java.util.*;
/**
 *
 * @author macstudent
 */
public class Person {
    String firstName;
    String lastName;
    int age;
    //default Constructor
    Person(){
    this.firstName = "Unknown";
    this.lastName = "Unknown";
    this.age = 1;
            
    }
    
    //Parameterized Constructor
     Person(String fNm, String lNm, int age){
    this.firstName = fNm;
    this.lastName = lNm;
    this.age = age;        
    }
     //Copy Constructor :  the values of the object are copied
     //passing the object as argument
     Person(Person object){
    this.firstName = object.firstName;
    this.lastName = object.lastName;
    this.age = object.age;        
    }
    void read(){
        Scanner input = new Scanner(System.in);
        
        System.out.println("Enter first name");
        this.firstName = input.nextLine();
        
         System.out.println("Enter last name");
        this.lastName = input.nextLine();
        
         System.out.println("Enter age");
        this.age = input.nextInt();
    }
    void display(){
         System.out.println("first name : " + this.firstName);
          System.out.println("last name : " + this.lastName);
           System.out.println("Age : " + this.age);
    }
}
