/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day4_task_students;

/**
 *
 * @author macstudent
 */
public class Students {
   
    int studentID;
     String name;
     String course;
     
     Students(){
     this.studentID = 0;
     this.name = "";
     this.course = "";
     }
    
    Students(int studentID , String name , String course)
    {
    this.studentID = studentID;
    this.name = name;
    this.course = course;
    }

    public int getStudentID() {
        return studentID;
    }

    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }
    
    void displayInfo(){
    System.out.println("Student ID is = " + studentID);
    System.out.println("Student name is = " + name);
    System.out.println("Student Course is = " + course);
    
    }
}
