/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day4_strings;
import java.util.ArrayList;
/**
 *
 * @author macstudent
 */
public class Day4_ArrayList {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Books b1 = new Books(1, "The Sky",12);
         Books b2 = new Books(2, "Above the stars",9);
          Books b3 = new Books(3, "Horizon",5);
           
          ArrayList <Books> library = new ArrayList<Books>();
          library.add(b1);
          library.add(b2);
           library.add(b3);
           
           System.out.println("Number of books = " + library.size());
           
           library.add(2,new Books(4,"The Universe",3));
           
         for(Books bk: library){
         bk.displayInfo();
          }
           
           library.forEach(bk ->{
               bk.displayInfo();
           });
    }
    
}
