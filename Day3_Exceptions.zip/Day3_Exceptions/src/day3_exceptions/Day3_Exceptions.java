/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day3_exceptions;

/**
 *
 * @author macstudent
 */
public class Day3_Exceptions {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int n1 = 10, n2 = 2;
        int arr[] = {10,20,30};
        
        try {
            if(n2 == 0)
            {
                //new is used to create a  new object of the exception
               throw new ArithmeticException(); 
            }
            else{
            n1 = n1 / n2;
            }
            
            n2 = arr[5];
            System.out.println("Value of n2 is : " + n2);
        }
        
     
        //Exception is the super class so it should be at the end of the hierarchy to met the other left over exceptions 
        catch(ArithmeticException e){
        System.out.println("Unable to divide by 0");
        }
        
        catch(ArrayIndexOutOfBoundsException e){
        System.out.println("Array Index not available");
        }
        
        catch(Exception e){
        System.out.println("Something Wrong....");
        }
        
        //the statements which are have to be generated should be written in the finally block
        finally{
        System.out.println("Value of n1 is : " + n1);
        
        }
    }
    
}
