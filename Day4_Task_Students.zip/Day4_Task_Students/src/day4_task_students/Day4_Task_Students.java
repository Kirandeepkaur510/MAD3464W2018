/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day4_task_students;
import java.util.ArrayList;
/**
 *
 * @author macstudent
 */
public class Day4_Task_Students {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Students s1 = new Students(1, "kiran" , "MADT");
         Students s2 = new Students(2, "Harinder","MADT");
          Students s3 = new Students(3, "Naveen","MADT");
           
          ArrayList <Students> database = new ArrayList<Students>();
          database.add(s1);
          database.add(s2);
           database.add(s3);
           
           System.out.println("Number of students = " + database.size());
           
          
           
         for(Students db: database){
         db.displayInfo();
          }
           
           
        
    }
    
}
