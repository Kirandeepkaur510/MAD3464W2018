/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reservationsystem;
import java.util.Scanner;

public class ReservationSystem 
{
    boolean[] seats = new boolean[11]; 
    Scanner input = new Scanner(System.in);

    public void start()
    {       
        while ( true )
        {
            makeReservation();
        }   
    }

    public void makeReservation()
    {
        System.out.println("Please type 1 for Smoking Section or 2 for Non-Smoking Section: ");
        int section = input.nextInt();
        if ( section == 1 )
        {
            smoking();
        }
        else
        {
            nonSmoking();
        }
    }

    public void smoking() // assign a first class seat
    {
        for ( int count = 1; count <= 5; count++ )
        {
            if ( seats[count] == false )  // if false, then a seat is available for assignment
            {
                seats[count] = true;  // assign seat
                System.out.printf("Smoking Section.... Seat No. %d\n", count);
                break;
            }
            else if ( seats[5] == true ) // If seating[5] is true then first class is fully booked
            {
                if ( seats[10] == true) // If seating[10] is true then economy (and therefore whole flight) is fully booked
                {
                    System.out.println("Sorry, flight fully booked ! Next flight is in 3 hours.");
                }
                else // ask passenger if they would like an economy ticket instead
                {
                    System.out.println("Smoking Section is fully booked. Would you like to prefer in Non Smoking Section? 1 for Yes, 2 for No");
                    int choice = input.nextInt();
                    if ( choice == 1 )
                    {
                        nonSmoking();
                        start();
                    }
                    else
                    {
                        System.out.println("Next flight is in 3 hours.");
                        System.exit(0);
                    }
                }
            }
        }
    }   

    public void nonSmoking() // assign an economy seat
    {
        for ( int count = 6; count <= 10; count++ )
        {
            if ( seats[count] == false ) // if false, then a seat is available for assignment
            {
                seats[count] = true; // assign seat
                System.out.printf("Non-Smoking Section....... Seat No. %d\n", count);
                break;
            }
            else if ( seats[10] == true ) // If seating[10] is true then economy is fully booked
            {
                if ( seats[5] == true) // If seating[5] is true then first class (and therefore whole flight) is fully booked
                {
                    System.out.println("Sorry, flight fully booked. Next flight is in 3 hours.");
                    System.exit(0);
                }
                else // ask if passenger would like a first class ticket instead
                {
                    System.out.println("Non-Smoking is fully booked. Would you like Smoking Section? 1 for Yes 2 for No");
                    int choice = input.nextInt();
                    if ( choice == 1 )
                    {
                        smoking();
                        start();
                    }
                    else
                    {
                        System.out.println("Next flight is in 3 hours");
                        System.exit(0);
                    }
                }
            }
        }
    }
   public static void main(String[] arg)
   {
      ReservationSystem RS = new ReservationSystem();
      RS.start();
      RS.makeReservation();
   }
}
