
import java.util.Arrays;
import java.util.Scanner;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
public class Hello {
   public static void main(String[] args)
   {
       //variables always starts with lower case but if it has second word then it would start with uppercase
       //int and float occupies 4 bytes
   int number = 35;
   float percentage = 56.67f;
   char vowel = 'a';
   String name = "Kiran";
   
   //System is a class in the java library it has three streams in , out , err
   //in for getting input keyboard and mouse  , out for getting output monitor/console ,err is using for getting an error message
   System.out.println("number : " + number);
   System.out.println("Percentage is : " + percentage);
   System.out.println("Vowel is : " +vowel);
   System.out.println("Name is : " + name);
   System.out.println("------*******------******-------********");
   number = 'r';
   percentage = 56f;
   vowel = 'a';
   name = "Kiran";
   System.out.println("number : " + number);
   System.out.println("Percentage is : " + percentage);
   System.out.println("Vowel is : " +vowel);
   System.out.println("Name is : " + name);
   number = 45;
   System.out.println(number + (1+2));
   System.out.println(1 + 2 + "test");
   
   if(number > 10)
   {
   System.out.println("Number is greater than 10");
   }
   else
   {
   System.out.println("Number is lower than 10");
   }
    switch (number) {
    case 10: 
    System.out.println("Number is 10");
    break;
    case 20:
    System.out.println("Number is 20");
    break;
    case 45: 
    System.out.println("Number is 45");
    break;
    default:
    System.out.println("Invalid number");
    break;
}
    
    
    switch(vowel){
       // case ('a' | 'e' | 'i' |'o' |'u'):
       case 'a':
           case 'e':
               case 'i':
                   case 'o':
                       case 'u':
         System.out.println("Vowel");   
         break;
        default:
            System.out.println("Not Vowel");
            break;
    }
    //Switch with string
    String province = "Ontario";
    switch(province) {
        case "Ontario" : 
            System.out.println("Province is Onatrio");
    break;
        default:
           System.out.println("Inavlid Province"); 
          break;
    }
  //Working with Arrays
    int numbers[] = new int[5];
    int i;
     int j;
    //for(i=0;i<=4;i++)
    //{
    //  numbers[i] = 10;
    //  System.out.println("numbers [" + i + "] = " +numbers[i]);
    //}
    for(i = 0 ; i < numbers.length ; i++)
    {
      numbers[i] = (int) (Math.random() * 100);
       System.out.println("numbers [" + i + "] = " +numbers[i]);
    }
   
    double PI_value = Math.PI;
    double power = Math.pow(2,4);
    Math.sqrt(23);
    Math.abs(PI_value);
    float grades[][] = new float[3][4];
    for(i=0;i<3;i++)
    {
       for(j=0;j<3;j++)
       {
           grades[i][j] = 10.0f;
       }
    }
    System.out.println("PI = " + PI_value);
     System.out.println("power = " + power);
    
    float randomNo;
    for(i=0;i<10;i++)
    {
    randomNo = (float)(Math.random()*10);
    System.out.println("no. " + (i+1) + " = " + randomNo);
    }
    System.out.println("--------");
     
     
     
   int randomNo1[] = new int[10];
   
   for(i=0;i<10;i++)
    {
    randomNo1[i] = (int)(Math.random()*10);
    System.out.println("no. " + (i+1) + " = " + randomNo1[i]);
    }
   System.out.println("Array in Ascending order");
   
    Arrays.sort(randomNo1);
    for(i=0;i<10;i++)
    {
    System.out.println("no. " + (i+1) + " = " + randomNo1[i]);
    }
    //Blank Sqaure
    System.out.println("First Pattern");
    for(i = 1; i <= 5; i++) 
    {
       for(j = 1; j <= 5 ; j++)
       {
           if(i==1 || i==5 || j==1 || j==5)
           {
             System.out.print("*"+" ");  
           }
           else{
             System.out.print("  ");   
           }
          
       }
       System.out.println("");
    }
  System.out.println("Second Pattern");
 
     Scanner sc = new Scanner(System.in);
         
        //Taking rows value from the user
         
        System.out.println("How many rows you want in this pattern?");
         
        int rows = sc.nextInt();
         
        System.out.println("Here is your pattern....!!!");
         
        //Printing upper half of the pattern
         
        for ( i = rows; i >= 1; i--) 
        {
            for (j = 1; j <= i; j++)
            {
                System.out.print(j+" ");
            }
             
            System.out.println();
        }
         
        //Printing lower half of the pattern
       
            
            
        
        //Closing the resources
         
        sc.close();
  
  
}
}
