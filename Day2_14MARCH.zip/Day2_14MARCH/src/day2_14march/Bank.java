/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day2_14march;

/**
 *
 * @author macstudent
 */
//the single public java class is converted to the byte code so  there is only one public class in the one java file


public class Bank {
 int bankId = 101;
 String bankName = "Scotia";
 
 
 void getBankID() 
  {
  System.out.println("Bank Name is : " + this.bankId);
  } 
  //this is keyword used to indicate the data member of that particular string
  void setBankID(int ide) 
  {
  this.bankId = ide;
  } 
  void getBankName() 
  {
  System.out.println("Bank Name is : " + this.bankName);
  } 
  //this is keyword used to indicate the data member of that particular string
  void setBankName(String name) 
  {
  this.bankName = name;
  } 
  
  
}


