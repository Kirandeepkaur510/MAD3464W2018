/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task_day3;
import java.util.*;
/**
 *
 * @author macstudent
 */
public class Task_Day3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Faculty F = new Faculty();
        F.readData();
       F.readValues();
        F.setData();
        F.displayData();
        F.displayValues();
       F.getData();
    }
    
}
class Person
{
String name;
int age;
public void readData(){
                Scanner input = new Scanner(System.in);
                System.out.println("Enter Name : ");
                name = input.nextLine();
                
                System.out.println("Enter Age : ");
                age = input.nextInt();
            }
public void displayData(){
    System.out.println("The name is : " + name);
    System.out.println("The age is : " + age);
           }
}

interface Employee 
{

 void readValues();
 
 void displayValues();
 
}


class Faculty extends Person implements Employee 
{
String course;
String type;
    int salary;
@Override
public void readValues(){
    
    Scanner input = new Scanner(System.in);
                System.out.println("Enter job type : ");
                type = input.nextLine();
                
                System.out.println("Enter salary : ");
                salary = input.nextInt();
} 
@Override
public void displayValues(){
System.out.println("The job type is : " + type);
    System.out.println("The salary is : " + salary);

}

public void setData(){
    
                Scanner input = new Scanner(System.in);
                System.out.println("Enter course : ");
                course = input.nextLine();
            }
public void getData(){
    
    System.out.println("The course is : " + course);
           }

}
