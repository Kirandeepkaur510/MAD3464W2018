/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day4_strings;

/**
 *
 * @author macstudent
 */
public class Books {
int bookID;
     String bookTitle;
     int bookRating;
     
     Books(){
     this.bookID = 0;
     this.bookTitle = "";
     this.bookRating = 0;
     }
    
    Books(int bookID , String bookTitle , int bookRating)
    {
    this.bookID = bookID;
    this.bookTitle = bookTitle;
    this.bookRating = bookRating;
    }

    public int getBookID() {
        return bookID;
    }

    public void setBookID(int bookID) {
        this.bookID = bookID;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public int getBookRating() {
        return bookRating;
    }

    public void setBookRating(int bookRating) {
        this.bookRating = bookRating;
    }

    void displayInfo(){
    System.out.println("BookId = " + bookID + "   " + "Book title is = " + bookTitle + "   " + "and book Rating is = " + bookRating);
    
    
    }
}
