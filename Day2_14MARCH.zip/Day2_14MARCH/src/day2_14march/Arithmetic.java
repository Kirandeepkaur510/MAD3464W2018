/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day2_14march;

/**
 *
 * @author macstudent
 */
public class Arithmetic 
{
    static int n1;
    final static int n2 = 56;
    //final keyword cannot be changed
    //final int a;
    //return int value
   int addition(int num1 , int num2)
   {
   return num1 + num2;
   }
  
   float addition(float num1 , float num2)
   {
   return num1 + num2;
   }
    //for addition of multiple values
    int addition(int... num)
   {  // num is array here
       int sum=0;
       for(int i=0;i<num.length;sum+=num[i],i++);
       return sum;
   }
    
    static int multiplication(int... num)
    {
    int i=0, answer = 1;
    for(i=0;i<num.length;i++)
    {
    answer*= num[i];
    }
    return answer;
    }
}
