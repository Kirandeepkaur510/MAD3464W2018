/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day3_interfaces;

/**
 *
 * @author macstudent
 */
public class Day3_Interfaces  {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
     //object of Addition Class  
    Addition op1 = new Addition();
    op1.display(); 
    
    System.out.println("-------------" );
     //object of Counting class Class  
    Counting C1 = new Counting();
    C1.display();
    
    System.out.println("-------------" );
     //object of A Class  
    A a1 = new A();
    a1.display();
    a1.calcMultiplication();
    
    System.out.println("-------------" );
    //objects of B class
    B b1 = new B();
    b1.display();
    b1.calcMultiplication();
    b1.calcDivision();
    
    System.out.println("-------------" );
    //objects of C class
    C c1 = new C();
    c1.display();
    c1.calcMultiplication();
    c1.calcDivision();
    } 
}

interface Arithmetic{
    int n1 = 9 , n2 = 10;
    void display();
}

class Addition implements Arithmetic
{
    //int n1 = 20 , n2 = 30;
    //yes we can change the variables
  @Override
   public void display()
   {
       
       System.out.println(n1 + "+" + n2 + "=" + (n1+n2) );
       System.out.println("Inside Addition Class" );
   }
}

class Counting extends Addition
{
//will access the method
}

interface multiplication extends Arithmetic{
void calcMultiplication();
}

class A implements multiplication{
@Override
   public void display(){
System.out.println("Addition is : " + (n1+n2) );
}
@Override
public void calcMultiplication(){
System.out.println("Multiplication is : " + (n1*n2) );
}  
}

interface division extends Arithmetic
{
void calcDivision();
}


class B extends Addition implements division,multiplication{

@Override
public void calcDivision(){
System.out.println("Division is : " + (n1/n2) );
}  

@Override
   public void display(){
       System.out.println("Inside Class B" );
System.out.println("Addition is : " + (n1+n2) );
}
   
 @Override
public void calcMultiplication(){
System.out.println("Multiplication is : " + (n1*n2) );
}  
}

class C extends B implements division, multiplication{
    
}
//interfaces arithmetic , multiplication , division
//classes A, B , counting , Addition
